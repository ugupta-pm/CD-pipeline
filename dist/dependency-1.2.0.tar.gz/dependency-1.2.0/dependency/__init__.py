from test_version import func

def hello():
    func()
